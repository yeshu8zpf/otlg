from __future__ import annotations

from typing import Any, Dict, List, Optional
import re


SUSPICIOUS_CONDITION_NAME_PATTERNS = [
    r"^is_",
    r"^has_",
    r"^can_",
    r"^should_",
    r"^enable",
    r"^enabled$",
    r"^active$",
    r"^valid$",
    r"^visible$",
    r"^public$",
    r"^private$",
    r"^status$",
    r"^state$",
    r"^type$",
    r"^kind$",
    r"^category$",
    r"^role$",
    r"^flag$",
    r"^publish$",
    r"^published$",
    r"^accepted$",
    r"^deleted$",
    r"^archived$",
]

DEFAULT_CONDITION_DECISION_STANDARDS = [
    "Use a class-level condition only when a column acts as a row-selection signal for class membership.",
    "Typical condition-candidate columns are status/type/flag/category/publish/active/valid columns.",
    "Do not use ordinary semantic attributes such as title, name, location, year, uri, or description as class-level conditions.",
    "Prefer no condition over an invented condition when evidence is weak.",
    "If a candidate condition is plausible but uncertain, keep class_mappings.condition as [] and add a needs_probe item.",
    "Binary or flag-like columns are stronger condition candidates than free-text columns.",
    "A class condition should narrow which rows instantiate the class; it should not merely restate a normal property.",
]


def _norm(s: str) -> str:
    return str(s or "").strip().lower()


def _looks_like_booleanish_sql_type(sql_type: str) -> bool:
    t = _norm(sql_type)
    return any(
        x in t
        for x in [
            "bool",
            "boolean",
            "tinyint(1)",
            "bit",
        ]
    )


def _looks_like_small_integer_type(sql_type: str) -> bool:
    t = _norm(sql_type)
    return any(
        x in t
        for x in [
            "tinyint",
            "smallint",
            "int",
            "integer",
        ]
    )


def _matches_suspicious_name(name: str) -> bool:
    n = _norm(name)
    for pat in SUSPICIOUS_CONDITION_NAME_PATTERNS:
        if re.search(pat, n):
            return True
    return False


def _candidate_conditions_for_column(column_name: str, column_type: str, table_name: str) -> List[Dict[str, Any]]:
    c = _norm(column_name)
    t = _norm(column_type)
    fq = f"{table_name}.{c}" if table_name else c

    out: List[Dict[str, Any]] = []

    if _looks_like_booleanish_sql_type(t):
        out.append(
            {
                "condition_sql": f"{fq} = 1",
                "confidence_hint": "medium",
                "rationale": "Boolean-like column may act as a class-membership filter.",
            }
        )
        out.append(
            {
                "condition_sql": f"{fq} = true",
                "confidence_hint": "low",
                "rationale": "Alternative boolean rendering depending on backend conventions.",
            }
        )

    elif _looks_like_small_integer_type(t) and _matches_suspicious_name(c):
        out.append(
            {
                "condition_sql": f"{fq} = 1",
                "confidence_hint": "medium",
                "rationale": "Integer status/flag column may encode active/published/valid subset membership.",
            }
        )

    if c in {"status", "state", "type", "kind", "category", "role"}:
        out.append(
            {
                "condition_sql": f"{fq} IS NOT NULL",
                "confidence_hint": "low",
                "rationale": "Type/status-like column may partition table rows into semantic subsets.",
            }
        )

    return out


def generate_condition_candidates_for_table(local_table: Dict[str, Any]) -> Dict[str, Any]:
    """
    Inspect one table definition and produce condition-revision hints.

    Expected input shape:
    {
      "name": "...",
      "columns": [
        {"name": "...", "type": "...", ...},
        ...
      ]
    }
    """
    table_name = _norm(local_table.get("name"))
    columns = local_table.get("columns", []) or []

    suspicious_columns: List[Dict[str, Any]] = []
    candidates: List[Dict[str, Any]] = []

    for col in columns:
        col_name = _norm(col.get("name"))
        col_type = _norm(col.get("type"))
        if not col_name:
            continue

        suspicious = _matches_suspicious_name(col_name)
        boolish = _looks_like_booleanish_sql_type(col_type)
        small_int = _looks_like_small_integer_type(col_type)

        if suspicious or boolish:
            suspicious_columns.append(
                {
                    "column": f"{table_name}.{col_name}" if table_name else col_name,
                    "name_signal": suspicious,
                    "type_signal": boolish or small_int,
                    "column_type": col_type,
                }
            )

            for cand in _candidate_conditions_for_column(col_name, col_type, table_name):
                candidates.append(
                    {
                        "column": f"{table_name}.{col_name}" if table_name else col_name,
                        **cand,
                    }
                )

    return {
        "table": table_name,
        "suspicious_columns": suspicious_columns,
        "candidates": candidates,
        "standards": list(DEFAULT_CONDITION_DECISION_STANDARDS),
    }


def condition_assessment_to_prompt_json(assessment: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "table": assessment.get("table", ""),
        "suspicious_columns": assessment.get("suspicious_columns", []),
        "candidates": assessment.get("candidates", []),
        "standards": assessment.get("standards", DEFAULT_CONDITION_DECISION_STANDARDS),
    }